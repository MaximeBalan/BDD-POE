INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Java Fullstack', '2022-10-24', '2023-01-27', 'POEI');
	
INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Java Fullstack', '2022-11-02', '2023-02-03', 'POEC');

INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Consultant Devops', '2022-06-13', '2022-09-16', 'POEC');
	
INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Consultant Cyber Sécurité', '2021-09-13', '2021-11-16', 'POEI');

INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Consultant SAP', '2022-04-13', '2022-08-16', 'POEI');
	
INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Consultant BI','2022-09-24','2022-11-23','POEI');	

INSERT INTO poes (title, begin_date, end_date,poe_type)
	VALUES ('Java Fullstack', '2022-07-02', '2022-10-20', 'POEC');