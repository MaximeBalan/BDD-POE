# SQL scripts
Put in this directory your scripts:
- SQL scripts
- shell scripts
- scripts archived (*.tar, *.tgz, *.zip)