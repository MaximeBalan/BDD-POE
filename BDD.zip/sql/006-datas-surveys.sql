--Surveys
--S1
INSERT INTO surveys (title)
	VALUES ('Formulaire de suivi de 1 mois');
	
--S2
INSERT INTO surveys (title)
	VALUES ('Formulaire de suivi de 6 mois');
	
--S3
INSERT INTO surveys (title)
	VALUES ('Formulaire de suivi de 12 mois');