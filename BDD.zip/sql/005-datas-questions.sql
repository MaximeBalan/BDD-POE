--Questions:
--Q1
INSERT INTO questions (title, question_type)
	VALUES ('Ton intégration a été ?', 'QCM');
--Q2
INSERT INTO questions (title, question_type)
	VALUES ('Tu es toujours en entreprise ?', 'YES_NO');
--Q3
INSERT INTO questions (title, question_type)
	VALUES ('As-tu changé de poste' ,'YES_NO');
--Q4
INSERT INTO questions (title, question_type)
	VALUES ('Avec lesquels de ces langages travailles tu ?', 'QCM');
--Q5
INSERT INTO questions (title, question_type)
	VALUES ('Sur quel projet travailles tu ?', 'FREE_RESPONSE');
--Q6
INSERT INTO questions (title, question_type)
	VALUES ('En vrai, t''es payé combien ?', 'FREE_RESPONSE');
--------------------------------------------------------------------------------
--Questions Formulaire 1 mois:
--Q7
INSERT INTO questions (title, question_type)
	VALUES ('Êtes-vous actuellement en emploi ?', 'YES_NO');
--Q8
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, depuis combien de temps ?', 'FREE_RESPONSE');
--Q9
INSERT INTO questions (title, question_type)
	VALUES ('Si non à Q1, avez-vous des processus de recrutement en cours ?' ,'YES_NO');
--Q10
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, comment s''est passé votre processus d''intégration dans l''entreprise ?', 'QCM');
--Q11
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, et que vous êtes basés chez le client, comment s''y est passée votre intégration ?', 'QCM');
--Q12
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, êtes-vous satisfait des missions confiées?', 'QCM');
--Q13
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, les missions confiées correspondent-elles à la formation que vous avez reçue ?', 'QCM');
--Q14
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, comment évaluerez-vous votre accompagnement sur vos projets (tuteur, manager, équipe projet...) ?', 'QCM');
--Q15
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à la Q1,  comment évaluez-vous votre relation avec l''équipe projet ?' ,'QCM');
--Q16
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1, comment évaluez-vous votre relation avec votre Employeur ?', 'QCM');
--Q17
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à la Q1,  et que vous êtes basé chez le Client, comment évaluez-vous votre relation avec votre manager Client ?', 'QCM');
--Q18
INSERT INTO questions (title, question_type)
	VALUES ('Si oui à Q1,  avez-vous été intégré avec un autre membre de votre promotion POE ?', 'YES_NO');

