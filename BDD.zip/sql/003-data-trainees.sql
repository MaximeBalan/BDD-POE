INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
	VALUES ('Neymar', 'Jean', '2000-05-21', 'jean@neymar.fr', 'M','0123456789', 1);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
	VALUES ('Bond', 'James', '1950-01-01', 'james@bond.org', 'M','0987654321', 1);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
	VALUES ('Weishar', 'Damien', '1989-05-21', 'damien@weishar.fr','M', '+337132456712', 1);
INSERT INTO trainees (lastname, firstname, birthdate, email,gender, phone_number, poe_id)
    VALUES ('Holmes','Mycroft','1852-08-05','mycroft.holmes@bp.uk','M', '0925836914', 1);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Baggins','Frodo','325-09-22','frodo@shire.me','M', '0494649394', 1);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Green', 'Rachel', '1972-11-06', 'rachel.green@gmail.com', 'F', '0485621970', 1);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
	VALUES ('Jones', 'Indiana', '1955-02-17', 'indiana@jones.fr', 'M','+336420285106', 2);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number,poe_id)
	VALUES ('Solo', 'Han', '1965-07-6', 'han@solo.fr', 'M','+336147258390', 2);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('polo', 'Jean', '1969-05-24', 'jean.@dodo.org','M','++336987654321', 2);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id) 
	VALUES ('Perrin','Maxime','2001-03-14','Saucissedu93@gmail.com', 'M','+336121212123', 3);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('De Nazareth', 'Jésus', '1000-01-01', 'jesusdenazareth@caramail.com', 'X', '012345678', 3);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Poppins', 'Mary', '1965-11-25', 'mary.poppins@disney.fr', 'F', '+33102030405', 3);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Iron', 'Man', '1969-05-31', 'iron@man.org', 'X', '+330102030407', 4);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Captain', 'Marvel', '1969-05-31', 'captain@marvel.org', 'F', '+330102030407', 4);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Sivoyon', 'Maeliss', '1991-01-18', 'sivoyon@maeliss.org', 'F', '+330102030409', 4);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Nebra', 'Mathieu', '1975-02-12', 'mathieu@nebra.org', 'M', '+330102030410', 5);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Egypte', 'Isis', '2002-08-03', 'egypte@isis.org', 'F', '+330102030411', 5);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Robie', 'Margot', '1985-12-24', 'robie@margot.org', 'F', '+330102030412', 5);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Leponge', 'Bob', '2001-11-30', 'bob@leponge.org', 'X', '+330102030413', 6);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Pedestre', 'Petit', '1974-03-21', 'petit@pedestre.org', 'M', '+330102030414', 6);  
INSERT INTO trainees (lastname, firstname, birthdate, email,gender, phone_number, poe_id)
    VALUES ('Holmes','Sherlock','1854-06-12','sherlock.holmes@baker.uk','M', '01472583690', 6);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Moriarty','James','1854-04-01','james.moriarty@london.uk','M', '0636982147', 7);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Miaou', 'Spatule', '2000-11-06', 'jaimelacroquette@miaou.fr', 'X', '0696385274',7);
INSERT INTO trainees (lastname, firstname, birthdate, email, gender, phone_number, poe_id)
    VALUES ('Africa', 'Toto', '1975-05-11', 'toto.africa@music.fr', 'M', '0798762453', 7);



