--Survey contains Question
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,7);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,8);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,9);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,10);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,11);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,12);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,13);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,14);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,15);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,16);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,17);
--Survey 1
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (1,18);

---------------------------------------------------------------	
--Survey 2
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (2,1);
--Survey 2
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (2,2);
--Survey 2
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (2,3);
--Survey 2
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (2,4);
	--Survey 2
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (2,5);
	--Survey 2
INSERT INTO survey_contains_question(survey_id, question_id)
	VALUES (2,6);
