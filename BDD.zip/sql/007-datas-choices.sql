--Choices
--choix 1
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 1);
--choix 2
INSERT INTO choices (name, question_id)
	VALUES ('Bien', 1);
--choix 3
INSERT INTO choices (name, question_id)
	VALUES ('Moyen', 1);
--choix 4
INSERT INTO choices (name, question_id)
	VALUES ('Médiocre', 1);
--choix 5
INSERT INTO choices (name, question_id)
	VALUES ('Java', 4);
--choix 6
INSERT INTO choices (name, question_id)
	VALUES ('Angular', 4);
--choix 7
INSERT INTO choices (name, question_id)
	VALUES ('Autre', 4);
--choix 8
INSERT INTO choices (name, question_id)
	VALUES ('Traitement des données GPS des sous-marins', 5);
--------------------------------------------------------------
--Choices for formulaire 1 mois
--choix 9
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 10);
--choix 10
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt bien', 10);
--choix 11
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt pas mal', 10);
--choix 12
INSERT INTO choices (name, question_id)
	VALUES ('Cela ne s''est pas bien passé', 10);
-------------------------
--choix 13
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 11);
--choix 14
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt bien', 11);
--choix 15
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt pas mal', 11);
--choix 16
INSERT INTO choices (name, question_id)
	VALUES ('Cela ne s''est pas bien passé', 11);
-------------------------
--choix 17
INSERT INTO choices (name, question_id)
	VALUES ('Oui parfaitement', 12);
--choix 18
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt oui', 12);
--choix 19
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt non', 12);
--choix 20
INSERT INTO choices (name, question_id)
	VALUES ('Non pas du tout', 12);
-------------------------
--choix 21
INSERT INTO choices (name, question_id)
	VALUES ('Oui parfaitement', 13);
--choix 22
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt oui', 13);
--choix 23
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt non', 13);
--choix 24
INSERT INTO choices (name, question_id)
	VALUES ('Non pas du tout', 13);
-------------------------
--choix 25
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 14);
--choix 26
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt bien', 14);
--choix 27
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt mauvais', 14);
--choix 28
INSERT INTO choices (name, question_id)
	VALUES ('Mauvais', 14);
-------------------------
--choix 29
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 15);
--choix 30
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt bien', 15);
--choix 31
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt mauvais', 15);
--choix 32
INSERT INTO choices (name, question_id)
	VALUES ('Mauvais', 15);
-------------------------
--choix 33
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 16);
--choix 34
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt bien', 16);
--choix 35
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt mauvais', 16);
--choix 36
INSERT INTO choices (name, question_id)
	VALUES ('Mauvais', 16);
-------------------------
--choix 37
INSERT INTO choices (name, question_id)
	VALUES ('Très bien', 17);
--choix 38
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt bien', 17);
--choix 39
INSERT INTO choices (name, question_id)
	VALUES ('Plutôt mauvais', 17);
--choix 40
INSERT INTO choices (name, question_id)
	VALUES ('Mauvais', 17);
-------------------------